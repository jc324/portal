# Review Request 34

**REQUEST TYPE**: `NEW_FACILITY_AND_PRODUCTS`
**CLIENT PROFILE**:

- **BUSINESS NAME**: `A&M Global Solutions, Inc`
- **WEBSITE**: `A&M Global Solutions, Inc`
- **DESCRIPTION**: `Food Group by A&M Global Solutions is part of an international vertically integrated group dedicated to the production and distribution of oats. Our factories are currently located in the United States, Venezuela, and Chile. We have the products and production capabilities to serve the retail market, the foodservice industry and supply raw materials needed by major food production companies.`

**HALAL ENFORCEMENT DIRECTOR**:

- **TYPE**: `INDIVIDUAL`
- **NAME**: ``
- **CONTACT NUMBER**: ``
- **EMAIL**: ``

## Facility 62

- **NAME**: ``
- **ADDRESS**: ``
- **CITY**: ``
- **STATE**: ``
- **ZIP**: ``
- **COUNTRY**: ``

## Products

- **Product 97**

  - **NAME**: `Coffee`
  - **DESCRIPTION**: `Here at John Doe incorporated our coffee is made of the finest coffee beans grown locally with chicory of the highest quality! We then add locally grown sugar, pour some boiling water over it and finally add the freshest milk and mix. The result is the best tasting coffee your taste buds have ever had the pleasure of tasting!`
  - **INGREDIENTS**:
    - INGREDIENT 297 (Coffee bean): `product_97_ingredient_297_doc_59_CERTIFICATE_OR_DISCLOSURE.pdf`

- **Product 98**

  - **NAME**: `Tea`
  - **DESCRIPTION**: `Lovely tea!`
  - **INGREDIENTS**:
