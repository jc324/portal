# Review Request 29

**REQUEST TYPE**: `NEW_FACILITY_AND_PRODUCTS`
**CLIENT PROFILE**:

- **BUSINESS NAME**: `Nail Alliance - North America Inc`
- **WEBSITE**: `Nail Alliance - North America Inc`
- **DESCRIPTION**: `Nail Alliance - North America, a professional nail enhancement manufacturer seeks to:

PROVIDE the salon industry with all of the tools needed to help make salon businesses even more successful with the latest and greatest in nail products.

ESTABLISH opportunity for learning through proper education and training courses domestically and internationally.

CREATE superiority within the industry as the go-to nail manufacturer for state-of-the-art products, proven to perform to the best of standards while upholding the motto "Done right from the start."

UNDERSTAND the needs of the salon industry. As nail professional ourselves, we have a clear understanding of the industry and the demand for the highest quality products and services possible – which is why quality has and will always be our number one priority.`

**HALAL ENFORCEMENT DIRECTOR**:

- **TYPE**: `INDIVIDUAL`
- **NAME**: ``
- **CONTACT NUMBER**: ``
- **EMAIL**: ``

## Facility 57

- **ID**: `MR57`
- **NAME**: `Nail Alliance - North America, Inc.`
- **ADDRESS**: `1545 Moonstone`
- **CITY**: `Brea`
- **STATE**: `Ca`
- **ZIP**: `92821`
- **COUNTRY**: `United States`

## Products
